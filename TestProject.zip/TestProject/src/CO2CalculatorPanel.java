import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CO2CalculatorPanel extends JPanel {
    private JTextField transportInput, energyInput, wasteInput;
    private JLabel resultLabel;

    public CO2CalculatorPanel() {
        setLayout(new GridLayout(5, 2));

        JLabel transportLabel = new JLabel("교통 (km): ");
        transportInput = new JTextField();
        JLabel energyLabel = new JLabel("에너지 사용량 (kWh): ");
        energyInput = new JTextField();
        JLabel wasteLabel = new JLabel("쓰레기 배출량 (kg): ");
        wasteInput = new JTextField();

        resultLabel = new JLabel("CO₂ 배출량: ");

        JButton calculateButton = new JButton("계산하기");
        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calculateCO2();
            }
        });

        add(transportLabel);
        add(transportInput);
        add(energyLabel);
        add(energyInput);
        add(wasteLabel);
        add(wasteInput);
        add(calculateButton);
        add(resultLabel);
    }

    private void calculateCO2() {
        double transport = Double.parseDouble(transportInput.getText());
        double energy = Double.parseDouble(energyInput.getText());
        double waste = Double.parseDouble(wasteInput.getText());

        double co2Total = transport * 0.21 + energy * 0.5 + waste * 0.17;
        resultLabel.setText("CO₂ 배출량: " + String.format("%.2f", co2Total) + " kg");
    }
}

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainFrame extends JFrame {
    private JPanel mainPanel;

    public MainFrame() {
        setTitle("AI Climate Change App");
        setSize(1200, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel menuPanel = new JPanel();
        menuPanel.setLayout(new GridLayout(6, 1));

        JButton dashboardButton = new JButton("홈 대시보드");
        JButton calculatorButton = new JButton("CO₂ 배출량 계산기");
        JButton visualizationButton = new JButton("기후 데이터 시각화");
        JButton chatbotButton = new JButton("AI 기반 챗봇");
        JButton challengesButton = new JButton("일일 에코 챌린지");
        JButton newsButton = new JButton("기후 뉴스 피드");


        dashboardButton.addActionListener(new DashboardListener());
        calculatorButton.addActionListener(new CalculatorListener());
        visualizationButton.addActionListener(new VisualizationListener());
        chatbotButton.addActionListener(new ChatbotListener());
        challengesButton.addActionListener(new ChallengeListener());
        newsButton.addActionListener(new NewsListener());

        menuPanel.add(dashboardButton);
        menuPanel.add(calculatorButton);
        menuPanel.add(visualizationButton);
        menuPanel.add(chatbotButton);
        menuPanel.add(challengesButton);
        menuPanel.add(newsButton);

        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        add(menuPanel, BorderLayout.WEST);
        add(mainPanel, BorderLayout.CENTER);

        setVisible(true);
    }

    // 리스너 클래스들
    private class DashboardListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            mainPanel.removeAll();
            mainPanel.add(new DashboardPanel());
            mainPanel.revalidate();
            mainPanel.repaint();
        }
    }

    private class CalculatorListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            mainPanel.removeAll();
            mainPanel.add(new CO2CalculatorPanel());
            mainPanel.revalidate();
            mainPanel.repaint();
        }
    }

    private class VisualizationListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            mainPanel.removeAll();
            mainPanel.add(new VisualizationPanel());
            mainPanel.revalidate();
            mainPanel.repaint();
        }
    }

    private class ChatbotListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            mainPanel.removeAll();
            mainPanel.add(new ChatbotPanel());
            mainPanel.revalidate();
            mainPanel.repaint();
        }
    }

    private class ChallengeListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            mainPanel.removeAll();
            mainPanel.add(new ChallengePanel());
            mainPanel.revalidate();
            mainPanel.repaint();
        }
    }

    private class NewsListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            mainPanel.removeAll();
            mainPanel.add(new NewsPanel());
            mainPanel.revalidate();
            mainPanel.repaint();
        }
    }

    public static void main(String[] args) {
        new MainFrame();
    }
}

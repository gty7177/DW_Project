import javax.swing.*;
import java.awt.*;

public class VisualizationPanel extends JPanel {
    public VisualizationPanel() {
        setLayout(new BorderLayout());

        JLabel title = new JLabel("기후 데이터 시각화", SwingConstants.CENTER);
        title.setFont(new Font("맑은 고딕", Font.BOLD, 24));

        add(title, BorderLayout.NORTH);
        add(new ClimateDataChart(), BorderLayout.CENTER);
    }

    private class ClimateDataChart extends JPanel {
        private int[] data = {70*3, 77*3, 85*3, 90*3, 120*3, 133*3, 145*3, 126*3, 142*3, 137*3}; // 샘플 데이터
        private String[] years = {"2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018", "2019"};

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.setFont(new Font("맑은 고딕", Font.PLAIN, 14));
            int width = getWidth() / data.length;

            for (int i = 0; i < data.length; i++) {
                int barHeight = data[i];
                switch (i){
                    case 0:
                        g.setColor(Color.GREEN);
                        break;
                    case 1:
                        g.setColor(Color.green);
                        break;
                    case 2:
                        g.setColor(Color.yellow);
                        break;
                    case 3:
                        g.setColor(Color.ORANGE);
                        break;
                    case 4:
                        g.setColor(Color.PINK);
                        break;
                    case 5:
                        g.setColor(Color.RED);
                        break;
                    case 6:
                        g.setColor(Color.GRAY);
                        break;
                }
                g.fillRect(i * width, getHeight() - barHeight, width - 10, barHeight);
                g.setColor(Color.BLACK);
                g.drawString(years[i], i * width + 10, getHeight() - 5);
            }
        }
    }
}

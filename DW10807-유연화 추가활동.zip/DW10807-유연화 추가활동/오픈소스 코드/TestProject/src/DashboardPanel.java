import javax.swing.*;
import java.awt.*;

public class DashboardPanel extends JPanel {
    private Image backgroundImage;

    public DashboardPanel() {


        
        backgroundImage = new ImageIcon(getClass().getResource("/background.jpg")).getImage();

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        Font titleFont = new Font("맑은 고딕", Font.BOLD, 24);
        Font textFont = new Font("맑은 고딕", Font.PLAIN, 18);

        JLabel title = new JLabel("홈 대시보드");
        title.setFont(titleFont);
        title.setAlignmentX(CENTER_ALIGNMENT);

        JLabel climateSummary = new JLabel("<html><body>현재 CO₂ 농도: 417 ppm<br>기온 상승: +1.2°C</body></html>");
        climateSummary.setFont(textFont);
        climateSummary.setForeground(Color.WHITE); 

        JLabel ecoTip = new JLabel("<html><body><b>오늘의 에코 팁:</b><br>전기를 절약하기 위해 불필요한 조명을 꺼주세요.</body></html>");
        ecoTip.setFont(textFont);
        ecoTip.setAlignmentX(CENTER_ALIGNMENT);
        ecoTip.setForeground(Color.WHITE); 


        add(title);
        add(Box.createVerticalStrut(20));
        add(climateSummary);
        add(Box.createVerticalStrut(20));
        add(ecoTip);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, 1000, 905, this);
        }
    }

}

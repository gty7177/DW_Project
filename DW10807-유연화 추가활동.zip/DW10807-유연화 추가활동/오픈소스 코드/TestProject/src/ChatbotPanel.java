import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class ChatbotPanel extends JPanel {
    private JTextArea chatArea;
    private JTextField inputField;

    public ChatbotPanel() {
                JLabel sourceLabel = new JLabel("출처 - DW10807 김태양");
        sourceLabel.setFont(new Font("맑은 고딕", Font.BOLD, 14));
        sourceLabel.setHorizontalAlignment(SwingConstants.RIGHT);

        setLayout(new BorderLayout());

        JLabel title = new JLabel("AI 챗봇", SwingConstants.CENTER);
        title.setFont(new Font("맑은 고딕", Font.BOLD, 24));
        add(title, BorderLayout.NORTH);

        chatArea = new JTextArea();
        chatArea.setEditable(false);
        chatArea.setFont(new Font("맑은 고딕", Font.PLAIN, 16));         add(new JScrollPane(chatArea), BorderLayout.CENTER);

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new BorderLayout());

        inputField = new JTextField();
        inputField.setFont(new Font("맑은 고딕", Font.PLAIN, 16));         inputField.setPreferredSize(new Dimension(300, 40)); 
        JButton sendButton = new JButton("보내기");
        sendButton.setFont(new Font("맑은 고딕", Font.BOLD, 16));         sendButton.setPreferredSize(new Dimension(100, 40)); 
        sendButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                sendMessage();
            }
        });

        inputField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    sendMessage();
                }
            }
        });

        inputPanel.add(inputField, BorderLayout.CENTER);
        inputPanel.add(sendButton, BorderLayout.EAST);

        add(inputPanel, BorderLayout.SOUTH);
    }

    private void sendMessage() {
        String userInput = inputField.getText();
        if (!userInput.isEmpty()) {
            chatArea.append("사용자: " + userInput + "\n");
            chatArea.append("챗봇: " + getBotResponse(userInput) + "\n\n");
            inputField.setText("");
        }
    }

    private String getBotResponse(String userInput) {
        if (userInput.contains("안녕")) {
            return "반갑습니다! 기후변화에 대한 질문이 있으신가요?";
        } else if (userInput.contains("뭐야")) {
            return "기후변화란 지구의 장기적인 기온과 날씨 패턴이 변화하는 현상을 말합니다. 주된 원인은 화석 연료 사용, 산림 파괴, 그리고 인간의 산업 활동으로 인한 온실가스 배출입니다.";
        } else if (userInput.contains("원인")) {
            return "기후변화의 주요 원인은 인간 활동으로 인한 온실가스 배출입니다. 특히, 이산화탄소, 메탄, 아산화질소와 같은 온실가스는 지구의 온도를 빠르게 높이고 있습니다.";
        } else if (userInput.contains("영향")) {
            return "기후변화는 전 세계적으로 큰 영향을 미치고 있습니다. 해수면 상승, 극단적인 기상 현상, 식량 부족, 생태계 파괴 등이 주요 영향입니다.";
        } else if (userInput.contains("방안") || userInput.contains("해결") || userInput.contains("대응")) {
            return "탄소 배출을 줄이는 것은 기후변화에 대응하는 가장 중요한 방법입니다. 재생 가능한 에너지 사용, 에너지 효율 개선, 그리고 친환경 교통수단 사용이 이에 해당합니다.";
        } else if (userInput.contains("통계")) {
            return "2023년 현재, 전 세계 기온은 산업화 이전 대비 약 1.2°C 상승했습니다. 이 상승은 전례 없는 속도로 이루어지고 있습니다.";
        } else if (userInput.contains("건강")) {
            return "기후변화는 인간 건강에도 부정적인 영향을 미칩니다. 더 자주 발생하는 폭염은 열사병 위험을 증가시키고, 기후 변화로 인해 감염병의 확산도 촉진됩니다.";
        } else if (userInput.contains("떙큐")) {
            return "네, 저도 감사합니다";
        }
        return "죄송합니다 " + userInput + "에 대한 질문은 대답할수없어요";
    }
}

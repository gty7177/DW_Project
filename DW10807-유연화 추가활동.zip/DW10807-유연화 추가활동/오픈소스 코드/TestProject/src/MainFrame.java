import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainFrame extends JFrame {
    private JPanel mainPanel;

    public MainFrame() {
        setTitle("안녕 기후변화 APp - DW10807 김태양");
        setSize(1200, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel menuPanel = new JPanel();
        menuPanel.setLayout(new GridLayout(7, 1));

        JButton dashboardButton = new JButton("홈 대시보드");
        JButton calculatorButton = new JButton("CO₂ 배출량 계산기");
        JButton visualizationButton = new JButton("기후 데이터 그래프");
        JButton chatbotButton = new JButton("AI 챗봇");
        JButton challengesButton = new JButton("일일 에코 챌린지");
        JButton newsButton = new JButton("기후 뉴스 피드");
        JButton createInButton = new JButton("제작");


        dashboardButton.addActionListener(new DashboardListener());
        calculatorButton.addActionListener(new CalculatorListener());
        visualizationButton.addActionListener(new VisualizationListener());
        chatbotButton.addActionListener(new ChatbotListener());
        challengesButton.addActionListener(new ChallengeListener());
        newsButton.addActionListener(new NewsListener());
        createInButton.addActionListener(new CreateInListener());

        menuPanel.add(dashboardButton);
        menuPanel.add(calculatorButton);
        menuPanel.add(visualizationButton);
        menuPanel.add(chatbotButton);
        menuPanel.add(challengesButton);
        menuPanel.add(newsButton);
        menuPanel.add(createInButton);

        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        add(menuPanel, BorderLayout.WEST);
        add(mainPanel, BorderLayout.CENTER);

        setVisible(true);
    }

    
    private class DashboardListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            mainPanel.removeAll();
            mainPanel.add(new DashboardPanel());
            mainPanel.revalidate();
            mainPanel.repaint();
        }
    }

    private class CalculatorListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            mainPanel.removeAll();
            mainPanel.add(new CO2CalculatorPanel());
            mainPanel.revalidate();
            mainPanel.repaint();
        }
    }

    private class VisualizationListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            mainPanel.removeAll();
            mainPanel.add(new VisualizationPanel());
            mainPanel.revalidate();
            mainPanel.repaint();
        }
    }

    private class ChatbotListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            mainPanel.removeAll();
            mainPanel.add(new ChatbotPanel());
            mainPanel.revalidate();
            mainPanel.repaint();
        }
    }

    private class ChallengeListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            mainPanel.removeAll();
            mainPanel.add(new ChallengePanel());
            mainPanel.revalidate();
            mainPanel.repaint();
        }
    }

    private class NewsListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            mainPanel.removeAll();
            mainPanel.add(new NewsPanel());
            mainPanel.revalidate();
            mainPanel.repaint();
        }
    }
    private class CreateInListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            mainPanel.removeAll();
            mainPanel.add(new CreateInPanel());
            mainPanel.revalidate();
            mainPanel.repaint();
        }
    }

    public static void main(String[] args) {
        new MainFrame();
    }
}

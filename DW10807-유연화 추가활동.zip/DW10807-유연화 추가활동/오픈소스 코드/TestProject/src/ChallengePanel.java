import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class ChallengePanel extends JPanel {
    private String[] challenges = {
            "플라스틱 사용 줄이기",
            "대중교통 이용하기",
            "에너지 절약하기",
            "음식물 쓰레기 줄이기",
            "물 절약하기"
    };

    public ChallengePanel() {
        
        JLabel sourceLabel = new JLabel("출처 - DW10807 김태양");
        sourceLabel.setFont(new Font("맑은 고딕", Font.BOLD, 14));
        sourceLabel.setHorizontalAlignment(SwingConstants.RIGHT);

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        JLabel title = new JLabel("일일 에코 챌린지");
        title.setFont(new Font("맑은 고딕", Font.BOLD, 24));
        title.setAlignmentX(CENTER_ALIGNMENT);

        JLabel challengeLabel = new JLabel(getRandomChallenge());
        challengeLabel.setFont(new Font("맑은 고딕", Font.PLAIN, 18));
        challengeLabel.setAlignmentX(CENTER_ALIGNMENT);

        JButton newChallengeButton = new JButton("새로운 챌린지 받기");
        newChallengeButton.setFont(new Font("맑은 고딕", Font.PLAIN, 18));
        newChallengeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                challengeLabel.setText(getRandomChallenge());
            }
        });

        add(title);
        add(Box.createVerticalStrut(20));
        add(challengeLabel);
        add(Box.createVerticalStrut(20));
        add(newChallengeButton);
    }

    private String getRandomChallenge() {
        Random random = new Random();
        int index = random.nextInt(challenges.length);
        return challenges[index];
    }
}

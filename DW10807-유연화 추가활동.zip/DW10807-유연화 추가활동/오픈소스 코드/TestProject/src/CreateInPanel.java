import javax.swing.*;
import java.awt.*;

public class CreateInPanel extends JPanel {
    public CreateInPanel() {


        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        JLabel title = new JLabel("제작자 / 출처");
        title.setFont(new Font("맑은 고딕", Font.BOLD, 24));
        title.setAlignmentX(CENTER_ALIGNMENT);

        JPanel newsPanel = new JPanel();
        newsPanel.setLayout(new BoxLayout(newsPanel, BoxLayout.Y_AXIS));

        String[] newsArticles = {
                "대원고등학교 유연화 수업 AI,기후변화 추가 활동\n",
                "\n",
                "제작 - DW10807 김태양\n",
                "제작언어 - Java, Javascript\n",
                "이미지 출처 - MEDICAL Observer 기사\n",
                "뉴스 기사 출처 - BBC NEWS 코리아\n"
        };

        for (String article : newsArticles) {
            JLabel newsLabel = new JLabel("• " + article);
            newsLabel.setFont(new Font("맑은 고딕", Font.PLAIN, 18));
            newsLabel.setAlignmentX(LEFT_ALIGNMENT);
            newsPanel.add(newsLabel);
            newsPanel.add(Box.createVerticalStrut(10));
        }


        JScrollPane scrollPane = new JScrollPane(newsPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setPreferredSize(new Dimension(400, 600));


        scrollPane.getVerticalScrollBar().setUnitIncrement(20);

        add(title);
        add(Box.createVerticalStrut(20));
        add(scrollPane);
    }
}

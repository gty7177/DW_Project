import javax.swing.*;
import java.awt.*;

public class NewsPanel extends JPanel {
    public NewsPanel() {

        
        JLabel sourceLabel = new JLabel("출처 - BBC NEWS 코리아");
        sourceLabel.setFont(new Font("맑은 고딕", Font.BOLD, 14));
        sourceLabel.setHorizontalAlignment(SwingConstants.RIGHT);

        
        add(sourceLabel, BorderLayout.NORTH);

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        JLabel title = new JLabel("기후 뉴스 피드");
        title.setFont(new Font("맑은 고딕", Font.BOLD, 24));
        title.setAlignmentX(CENTER_ALIGNMENT);

        JPanel newsPanel = new JPanel();
        newsPanel.setLayout(new BoxLayout(newsPanel, BoxLayout.Y_AXIS));

        String[] newsArticles = {
                "어미 북극곰과 새끼 북극곰 2마리사진 출처,USGS\n",
                "사진 설명,북극의 기온이 오르면서 북극곰들이 점점 더 육지에서 보내는 시간이 많아지고 있다\n",
                "기사 관련 정보\n",
                "기자,빅토리아 길\n",
                "기자,BBC 과학 전문기자\n",
                "2024년 10월 25일\n",
                "북극의 기온이 오르면서 북극곰이 불과 30년 전만 해도 마주칠 가능성이 적었던 바이러스, 박테리아, 기생충 등에 감염될 위험이 커지고 있다는 연구 결과가 발표됐다.\n",
                "\n",
                "과학자들은 북극곰의 질병 감염 가능성과 북극의 해빙 손실 간 어떤 관련이 있는지 살펴보고자 러시아와 알래스카 사이 추크치해에 사는 북극곰들의 혈액 표본을 조사했다.\n",
                "\n",
                "1987~1994년 사이 채취한 샘플과 이로부터 30년 후인 2008~2017년 사이 채취한 표본을 분석했더니, 최근 채취된 표본에서 북극곰들이 5가지 바이러스, 박테리아 또는 기생충 중 하나에 감염됐음을 가리키는 화학적 신호가 더 많이 포착됐다.\n",
                "\n",
                "미국 ‘지질조사국’의 야생동물 생물학자 카린 로드 박사와 진정제를 맞고 누워 있는 야생 북극곰사진 출처,USGS\n",
                "사진 설명,야생동물 생물학자인 카린 로드(사진 속 야생 북극곰은 진정제를 맞은 상태다)와 동료 연구진은 북극곰의 건강 상태를 살펴보고자 혈액 샘플을 채취했다\n",
                "남극 해빙 손실로 새끼 황제펭귄 수천 마리 떼죽음\n",
                "2023년 8월 28일\n",
                "남극 해빙 면적, 관측 이래 최저치 기록\n",
                "2023년 2월 17일\n",
                "얼음의 노래부터 자원 탐사 소음까지 … 남극과 북극의 희귀한 소리 포착\n",
                "2023년 2월 12일\n",
                "혈액 표본만으로 북극곰의 신체적 건강에 끼치는 영향을 전부 알기는 어렵지만, 미국’ 지질조사국’ 소속 야생동물 생물학자인 카린 로드 박사는 북극 생태계 전체에 무언가 변화가 일어나고 있음은 알 수 있다고 설명했다.\n",
                "\n",
                "로드 박사와 연구진은 총 6가지 병원균을 검사했다. 주로 육지 동물과 관련 있으나, 북극곰의 먹이가 되는 생물을 포함한 해양 동물에서도 발견된 기록이 있는 바이러스, 박테리아, 기생충이다.\n",
                "\n",
                "이번 연구는 30년에 걸쳐 이뤄졌는데, 로드 박사에 따르면 “해빙이 상당 부분 손실되고, (북극곰들이) 육지에서 보내는 시간이 늘어났던 기간”이라고 한다.\n",
                "\n",
                "“그래서 저희는 특히 주로 육지에서 기원했다고 생각하는 일부 병원균에 대한 (북극곰들의) 노출 정도가 변했는지 알고 싶었습니다.”\n",
                "\n",
                "과거에 비해 북극곰 체내에서 더 흔하게 발견되는 병원체로는 톡소플라즈마증과 네오스포라증을 일으키는 기생충 2종, 야토병과 브루셀라증을 일으키는 박테리아 2종, 개 홍역을 일으키는 바이러스 1개 등 총 5가지로 밝혀졌다.\n",
                "\n",
                "로드 박사는 “일반적으로 북극곰들은 질병에 매우 강하다”면서 “(이러한 병원체와의 접촉이) 일반적으로 곰 개체수에 영향을 미치지는 않는 것으로 알려져 있지만, 그래도 (북극의) 상황이 변하고 있다는 점을 잘 보여준다고 생각한다”고 덧붙였다.\n",
                "\n",
                "북극곰 관련 주요 정보\n",
                "전 세계적으로 북극곰 약 2만6000마리가 남아 있으며, 대부분 캐나다에 서식하고 있다. 미국, 러시아, 그린란드, 노르웨이에서도 북극곰이 발견된다.\n",
                "북극곰은 ‘국제자연보전연맹(IUCN)’에서 멸종 취약한 종으로 분류하고 있으며, 기후 변화가 북극곰 개체 수 감소의 주요 요인으로 꼽힌다.\n",
                "성체 수컷 북극곰은 몸길이가 3m, 무게가 600kg에 달할 수 있다.\n",
                "북극곰은 한 번에 최대 45kg에 달하는 해양 동물 지방을 먹을 수 있다.\n",
                "북극곰은 특히 후각이 뛰어나 최대 16km 떨어진 먹이의 냄새도 맡을 수 있다.\n",
                "북극곰은 뛰어난 수영 선수로, 최대 100km 앞바다에서도 헤엄치는 모습이 포착되곤 한다. 발에는 작은 물갈퀴가 있어 시속 10km 정도의 속도로 헤엄칠 수 있다.\n",
                "목걸이형 카메라에 포착된 북극곰 무리사진 출처,USGS\n",
                "사진 설명,목걸이형 카메라를 이용한 연구로 북극곰이 얼음이 없는 여름철에는 무엇을 먹는지, 얼마나 놀라운 사회적 상호작용을 하는지 등이 밝혀졌다\n",
                "한편 미국에서 북극곰은 멸종 위기 종으로 분류돼 있는데, 과학자들이 지적하는 북극곰 개체 수 감소의 가장 큰 원인은 바로 해빙 유실이다. 북극곰들은 해빙에서 살아가며 해양 동물을 사냥하며 살아가기 때문이다.\n",
                "\n",
                "북극곰에 목걸이형 카메라를 씌워 진행한 이전 연구에 따르면 사냥에 나설 해빙이 없어지면 북극곰들은 육지에서 더 많은 시간을 보내게 되고, 이에 따라 북극곰들은 충분한 열량을 섭취하지 못하고 있다고 한다.\n",
                "\n",
                "로드 박사는 북극곰은 최상위 포식자라면서 “이번 우리 연구에 따르면 북극곰은 주로 먹이를 통해 일부 병원균에 노출된다”고 설명했다.\n",
                "\n",
                "“따라서 북극곰이 노출되는 병원체에 변화가 있다는 것은 다른 생물종들도 변화를 겪고 있다는 뜻입니다.”\n",
                "\n",
                "이번 연구 결과는 과학 학술지 ‘PLOS One’에 게재됐다."
        };

        for (String article : newsArticles) {
            JLabel newsLabel = new JLabel("• " + article);
            newsLabel.setFont(new Font("맑은 고딕", Font.PLAIN, 18));
            newsLabel.setAlignmentX(LEFT_ALIGNMENT);
            newsPanel.add(newsLabel);
            newsPanel.add(Box.createVerticalStrut(10)); 
        }

        
        JScrollPane scrollPane = new JScrollPane(newsPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setPreferredSize(new Dimension(400, 600)); 

        
        scrollPane.getVerticalScrollBar().setUnitIncrement(20); 

        add(title);
        add(Box.createVerticalStrut(20));
        add(scrollPane);
    }
}

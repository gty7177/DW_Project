import javax.swing.*;
import java.awt.*;

public class VisualizationPanel extends JPanel {
    public VisualizationPanel() {
        
        JLabel sourceLabel = new JLabel("출처 - DW10807 김태양");
        sourceLabel.setFont(new Font("맑은 고딕", Font.BOLD, 14));
        sourceLabel.setHorizontalAlignment(SwingConstants.RIGHT);

        setLayout(new BorderLayout());

        JLabel title = new JLabel("기후 데이터 - 년도별 평균온도", SwingConstants.CENTER);
        title.setFont(new Font("맑은 고딕", Font.BOLD, 24));

        add(title, BorderLayout.NORTH);
        add(new ClimateDataChart(), BorderLayout.CENTER);
    }

    private class ClimateDataChart extends JPanel {
        private int[] data = {210, 231, 255, 270, 360, 399, 435, 378, 426, 411}; 
        private String[] years = {"2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018", "2019"};
        private Color[] colors = {new Color(12, 105, 0), new Color(17, 140, 1), new Color(22, 176, 2),
                new Color(25, 219, 0), new Color(145, 252, 131), new Color(255, 90, 84),
                new Color(247, 64, 57), new Color(214, 12, 4), new Color(163, 11, 5), new Color(138, 8, 3)};

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.setFont(new Font("맑은 고딕", Font.BOLD, 16));
            int width = getWidth() / data.length;

            for (int i = 0; i < data.length; i++) {
                int barHeight = data[i];
                g.setColor(colors[Math.min(i, colors.length - 1)]);
                g.fillRect(i * width + 5, getHeight() - barHeight - 20, width - 10, barHeight);
                g.setColor(Color.BLACK);
                g.drawString(years[i], i * width + 15, getHeight() - barHeight - 25);
            }
        }
    }
}
